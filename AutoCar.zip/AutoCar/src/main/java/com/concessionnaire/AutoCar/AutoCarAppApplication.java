package com.concessionnaire.AutoCar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoCarAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoCarAppApplication.class, args);
	}

}
