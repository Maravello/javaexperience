package com.concessionnaire.AutoCar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoCarAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
